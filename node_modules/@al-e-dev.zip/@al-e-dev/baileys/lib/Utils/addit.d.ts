export declare const convertTimeOut: (ms: number) => string;
